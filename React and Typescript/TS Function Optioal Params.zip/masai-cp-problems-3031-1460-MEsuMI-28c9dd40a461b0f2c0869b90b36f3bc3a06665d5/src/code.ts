// This the function
const getName = () =>{
    
}

export default getName;// Make no changes here