
const func = () => {
};
export default func;
