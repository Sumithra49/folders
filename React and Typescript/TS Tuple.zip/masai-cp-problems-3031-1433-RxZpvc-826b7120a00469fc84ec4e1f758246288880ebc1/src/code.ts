let tuple;// this variable should be the Tuple
export default tuple;// Make no changes here
