

function Reduce(){
}
export default Reduce;