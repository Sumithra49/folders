

class Cow {
}

export default Cow;