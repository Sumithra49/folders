export interface IAnimal{
    
}