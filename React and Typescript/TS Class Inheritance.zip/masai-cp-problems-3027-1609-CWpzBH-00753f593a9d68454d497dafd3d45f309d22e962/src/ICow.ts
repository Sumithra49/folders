export interface ICow {
    
}