
class Animal{
}

export default Animal;