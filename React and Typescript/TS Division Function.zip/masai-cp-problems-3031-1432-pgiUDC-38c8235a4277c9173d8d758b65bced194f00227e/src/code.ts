
const func = () => {
};
export default func;// Make no changes here 
