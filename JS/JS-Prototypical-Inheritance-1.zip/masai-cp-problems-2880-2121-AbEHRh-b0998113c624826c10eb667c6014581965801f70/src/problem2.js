//Person constructor function

function Person(name, age) {

}

// let person =new Person ("Priya",28)
// console.log(person)//{name:"Priya",age:28}
// console.log(person.getDetails())//Priya is 28 years old.
// console.log(person.increaseAge()) //29
// console.log(person)//{name:"Priya",age:29};
// console.log(person.decreaseAge()) //28
// console.log(person)//{name:"Priya",age:28};

//to create Employee constructor function

function Employee(name, age, salary) {

}

// let employee1 = new Employee("Ram", 45, 150000);
// console.log(employee1); //{name:"Ram",age:45,salary:150000}
// console.log(employee1.getDetails()); // "Hi I am Ram and I am 45 years old and my salary is 150000."
// console.log(employee1.increaseAge()); //46
// console.log(employee1.decreaseAge()); //45
// console.log(employee1.decreaseAge()); //44
// console.log(employee1.increaseSalary(50000)); //200000;
// console.log(employee1); //{name:"Ram",age:45,salary:200000}
// console.log(employee1.decreaseSalary(30000)); //170000;
// console.log(employee1); //{name:"Ram",age:45,salary:170000}

//to create Manager constructor function

function Manager(name, age, salary, team) {

}

// let manager1 = new Manager("Virat", 30, 50000, "developer");
// console.log(manager1.getDetails()); //"Hi I am Virat and I am 30 years old and my salary is 50000 and I am a manager."
// console.log(manager1.manageTeam())//"I am Virat and I manage developer team."

//to create Accountant constructor function

function Accountant(name, age, salary, clients) {

}

// let accountant1 = new Accountant("Ankur",27,500000,["tcs","wipro"]);
// console.log(accountant1)//{name:"Ankur",age:27,salary:500000,clients:["tcs","wipro"]}

// accountant1.getDetails()//Hi I am Ankur and I am 27 years old and my salary is 500000 and I am an accountant.

// accountant1.addClient("pwc");//pwc added successfully.
// console.log(accountant1)//{name:"Ankur",age:27,salary:500000,clients:["tcs","wipro","pwc"]}

// accountant1.removeClient("wipro");//wipro removed successfully.
// console.log(accountant1)//{name:"Ankur",age:27,salary:500000,clients:["tcs","pwc"]}

//to create SeniorManager constructor function

function SeniorManager(name, age, salary, team, yearsInPosition) {

}

export {
  Person,
  Employee,
  Manager,
  Accountant,
  // Developer,
  SeniorManager,
  // SeniorDeveloper,
};
