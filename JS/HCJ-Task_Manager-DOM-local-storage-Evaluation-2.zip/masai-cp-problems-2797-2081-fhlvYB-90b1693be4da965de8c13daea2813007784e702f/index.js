let taskNameInput = document.getElementById("taskName");
let prioritySelect = document.getElementById("priority");
let submitBtn = document.getElementById("submitBtn");
let tbody = document.querySelector("tbody");
