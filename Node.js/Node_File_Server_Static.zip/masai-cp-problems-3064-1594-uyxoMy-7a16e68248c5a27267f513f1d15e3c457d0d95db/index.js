const http = require("http");
const fs = require("fs");
const PORT = 7700;

const server =" create the server";

// export your server
