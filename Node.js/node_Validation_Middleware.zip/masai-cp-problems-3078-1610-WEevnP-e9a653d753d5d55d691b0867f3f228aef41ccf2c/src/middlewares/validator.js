const fs = require("fs");

// make the validator function and export it.


// module.exports = validatorfunction;
